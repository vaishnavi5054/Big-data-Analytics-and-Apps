//
//  ThirdViewController.h
//  SG17tutorial
//
//  Created by Aienampudi, Lakshmi Vaishnavi (UMKC-Student) on 6/12/15.
//  Copyright (c) 2015 Aienampudi, Lakshmi Vaishnavi (UMKC-Student). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController

@end
