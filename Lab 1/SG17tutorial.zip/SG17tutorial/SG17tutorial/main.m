//
//  main.m
//  SG17tutorial
//
//  Created by Aienampudi, Lakshmi Vaishnavi (UMKC-Student) on 6/12/15.
//  Copyright (c) 2015 Aienampudi, Lakshmi Vaishnavi (UMKC-Student). All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
