//
//  ViewController.m
//  Textspeech
//
//  Created by RENUKA on 19/06/15.
//  Copyright (c) 2015 RENUKA. All rights reserved.
//

#import "ViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>


#define BASE_URL "http://tts-api.com/tts.mp3?"

@interface ViewController ()
{
    AVAudioPlayer *_audioPlayer;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)Pressbutton:(id)sender {
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSString *sentense = [_entertext.text stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    
   

    
    NSString *url = [NSString stringWithFormat:@"%sq=%@", BASE_URL, sentense];
    //NSLog(@"URL is %@", url);
    
    
    
    
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"JSON: %@", responseObject);
        operation.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"audio/mpeg", nil];
        
        
        
        NSLog(@"NSObject: %@", responseObject);
        
        NSData *audioData = responseObject;
        
        [[AVAudioSession sharedInstance]setCategory:AVAudioSessionCategoryPlayback error:Nil];
        [[AVAudioSession sharedInstance]setActive:YES error:Nil];
        
        self->_audioPlayer = [[AVAudioPlayer alloc]initWithData:audioData error:Nil];
        
        [self->_audioPlayer prepareToPlay];
        [self->_audioPlayer play];
        
    }failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                        message:[error description]
                                                       delegate:nil
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
        [alert show];
     
         }];

}
@end

