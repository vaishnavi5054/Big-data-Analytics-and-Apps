//
//  AppDelegate.h
//  Textspeech
//
//  Created by RENUKA on 19/06/15.
//  Copyright (c) 2015 RENUKA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

