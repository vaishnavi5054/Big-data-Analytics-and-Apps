//
//  Weather.h
//  SimpleWeather
//
//  Created by RENUKA on 19/06/15.
//  Copyright (c) 2015 RENUKA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Weather : NSObject

// Properties
// ==========

// Place and time
@property (nonatomic, copy, readonly) NSString *city;
@property (nonatomic, copy, readonly) NSString *country;
@property (nonatomic, readonly) float latitude;
@property (nonatomic, readonly) float longitude;
@property (nonatomic, copy, readonly) NSDate *reportTime;
@property (nonatomic, copy, readonly) NSDate *sunrise;
@property (nonatomic, copy, readonly) NSDate *sunset;

// Qualitative
@property (nonatomic, copy, readonly) NSArray *conditions;

// Quantitative
@property (nonatomic, readonly) NSInteger cloudCover;
@property (nonatomic, readonly) NSInteger humidity;
@property (nonatomic, readonly) NSInteger pressure;
@property (nonatomic, readonly) NSInteger rain3hours;
@property (nonatomic, readonly) NSInteger snow3hours;
@property (nonatomic, readonly) float tempCurrent;
@property (nonatomic, readonly) float tempMin;
@property (nonatomic, readonly) float tempMax;
@property (nonatomic, readonly) NSInteger windDirection;
@property (nonatomic, readonly) float windSpeed;

- (void)getCurrent:(NSString *)query;



@end
