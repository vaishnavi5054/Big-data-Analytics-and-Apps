//
//  ViewController.m
//  weatherspeech
//
//  Created by RENUKA on 19/06/15.
//  Copyright (c) 2015 RENUKA. All rights reserved.
//

#import "ViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>


#define BASE_URL "http://api.openweathermap.org/data/2.5/weather?"
#define BASE_URL2 "http://tts-api.com/tts.mp3?"





@interface ViewController ()
{
    
        AVAudioPlayer *_audioPlayer;
}

@property (strong, nonatomic) NSString *temp;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)clickme:(id)sender {
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];

    NSString *sentense = [_entercity.text stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    
    NSString *url = [NSString stringWithFormat:@"%sq=%@", BASE_URL, sentense];
   
    
    [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSLog(@"JSON: %@", responseObject);
        
        NSDictionary *details = [responseObject objectForKey:@"main"];
        NSString *temp = [details objectForKey:@"temp"];
        NSString *temp_min = [details objectForKey:@"temp_min"];
        
     
     //   NSArray *array=[responseObject objectForKey:@"weather"];
       // NSDictionary *details2=[array objectAtIndex:0];
      //  NSString *description=[details2 objectForKey:@"description"];
        
        NSLog(@"temp: %@", temp);
        NSLog(@"temp_min:%@", temp_min);
        
         NSString *messageBody = [NSString stringWithFormat:@"temp: %@,@temp_min: %@", temp, temp_min];
        
        //////////
        
        NSString *sentence = [messageBody stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        
        
        NSString *url = [NSString stringWithFormat:@"%sq=%@",BASE_URL2 , sentence];
        
        NSLog(@"url is: %@",url);
        
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            operation.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"audio/mpeg",nil];
            
            
            
            NSLog(@"NSObject: %@", responseObject);
            
            NSData *audioData = responseObject;
            
            [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
            [[AVAudioSession sharedInstance] setActive:YES error:nil];
            
            self->_audioPlayer = [[AVAudioPlayer alloc] initWithData:audioData error:nil]; // audioPlayer must be a strong property. Do not create it locally
            
            [self->_audioPlayer prepareToPlay];
            [self->_audioPlayer play];
            
            // NSLog(@"responseString: %@", responseString);
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"Error: %@", error);
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                            message:[error description]
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil, nil];
            [alert show];
        }];
    
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                                        message:[error description]
                                                       delegate:nil
                                              cancelButtonTitle:@"Ok"
                                              otherButtonTitles:nil, nil];
        [alert show];
    }];
}
@end
