//
//  ViewController.h
//  weatherspeech
//
//  Created by RENUKA on 19/06/15.
//  Copyright (c) 2015 RENUKA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *citylabel;

@property (strong, nonatomic) IBOutlet UITextField *entercity;
- (IBAction)clickme:(id)sender;


@end

